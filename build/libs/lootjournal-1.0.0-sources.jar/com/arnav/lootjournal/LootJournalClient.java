package com.arnav.lootjournal;

import com.arnav.lootjournal.session.SessionTracker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public class LootJournalClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        LootJournalConfig.load();
        LootJournalKeys.register();

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String worldName = resolveWorldName(client);
            SessionTracker.start(client, worldName);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            SessionTracker.end(client);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            SessionTracker.tick(client);

            if (LootJournalKeys.showReport != null && LootJournalKeys.showReport.method_1436()) {
                SessionTracker.printMidSessionReport(client);
            }

            if (LootJournalKeys.openSettings != null && LootJournalKeys.openSettings.method_1436()
                    && client.field_1755 == null) {
                client.method_1507(new LootJournalConfigScreen(null));
            }
        });
    }

    private String resolveWorldName(class_310 client) {
        if (client.method_1558() != null) {
            return client.method_1558().field_3761;
        }
        if (client.method_1576() != null) {
            return client.method_1576().method_27728().method_150();
        }
        return "unknown";
    }
}

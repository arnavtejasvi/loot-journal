package com.arnav.lootjournal.session;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
public record InventorySnapshot(Map<String, Integer> items, int totalXp) {

    public static InventorySnapshot of(class_1657 player) {
        Map<String, Integer> counts = new HashMap<>();
        List<class_1799> allSlots = new java.util.ArrayList<>();
        player.method_31548().field_7547.forEach(allSlots::add);
        player.method_31548().field_7548.forEach(allSlots::add);
        player.method_31548().field_7544.forEach(allSlots::add);

        for (class_1799 stack : allSlots) {
            if (stack.method_7960()) continue;
            String key = stack.method_7909().method_7876();
            counts.merge(key, stack.method_7947(), Integer::sum);
        }
        return new InventorySnapshot(counts, player.field_7495);
    }

    public static Map<String, Integer> diffGained(InventorySnapshot before, InventorySnapshot after) {
        Map<String, Integer> gained = new HashMap<>();
        for (Map.Entry<String, Integer> entry : after.items().entrySet()) {
            int beforeCount = before.items().getOrDefault(entry.getKey(), 0);
            int delta = entry.getValue() - beforeCount;
            if (delta > 0) gained.put(entry.getKey(), delta);
        }
        return gained;
    }

    public static Map<String, Integer> diffLost(InventorySnapshot before, InventorySnapshot after) {
        Map<String, Integer> lost = new HashMap<>();
        for (Map.Entry<String, Integer> entry : before.items().entrySet()) {
            int afterCount = after.items().getOrDefault(entry.getKey(), 0);
            int delta = entry.getValue() - afterCount;
            if (delta > 0) lost.put(entry.getKey(), delta);
        }
        return lost;
    }
}

package com.arnav.lootjournal;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class LootJournalKeys {
    public static class_304 showReport;
    public static class_304 openSettings;

    private LootJournalKeys() {}

    public static void register() {
        showReport = KeyBindingHelper.registerKeyBinding(new class_304(
                "lootjournal.key.show_report",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                "lootjournal.key.category"
        ));
        openSettings = KeyBindingHelper.registerKeyBinding(new class_304(
                "lootjournal.key.open_settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN, // unbound by default — user assigns in Controls
                "lootjournal.key.category"
        ));
    }
}

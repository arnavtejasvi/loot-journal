package com.arnav.lootjournal.mixin;

import com.arnav.lootjournal.session.SessionTracker;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Unique private class_2680 lootjournal$pendingBlock;
    @Unique private class_2338 lootjournal$pendingPos;

    @Inject(
        method = "breakBlock(Lnet/minecraft/util/math/BlockPos;)Z",
        at = @At("HEAD")
    )
    private void lootjournal$capturePre(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            this.lootjournal$pendingBlock = client.field_1687.method_8320(pos);
            this.lootjournal$pendingPos = pos.method_10062();
        }
    }

    @Inject(
        method = "breakBlock(Lnet/minecraft/util/math/BlockPos;)Z",
        at = @At("TAIL")
    )
    private void lootjournal$capturePost(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (Boolean.TRUE.equals(cir.getReturnValue()) && this.lootjournal$pendingBlock != null) {
            class_310 client = class_310.method_1551();
            long tick = client.field_1687 != null ? client.field_1687.method_8510() : 0L;
            String blockId = class_7923.field_41175.method_10221(this.lootjournal$pendingBlock.method_26204()).toString();
            class_2338 p = this.lootjournal$pendingPos;
            SessionTracker.onBlockBroken(blockId, p.method_10263(), p.method_10264(), p.method_10260(), tick);
        }
        this.lootjournal$pendingBlock = null;
        this.lootjournal$pendingPos = null;
    }
}

package com.arnav.lootjournal;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
public class LootJournalConfigScreen extends class_437 {
    private final class_437 parent;
    private int windowLabelY;

    public LootJournalConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Loot Journal Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx    = this.field_22789 / 2;
        int y     = 32;
        int gap   = 24;

        // Master toggle
        addToggle(cx, y, "Loot Journal Enabled", LootJournalConfig.enabled,
                v -> LootJournalConfig.enabled = v);
        y += gap;

        // ── Block Randomizer Mode ─────────────────────────────────────────────
        // Rebuilds the screen so the dependent BR feedback button reflects the new state.
        this.method_37063(class_4185.method_46430(brModeText(), btn -> {
            LootJournalConfig.blockRandomizerMode = !LootJournalConfig.blockRandomizerMode;
            if (LootJournalConfig.blockRandomizerMode
                    && LootJournalConfig.attributionWindowTicks < 100) {
                LootJournalConfig.attributionWindowTicks = 100;
            }
            this.method_41843();
        }).method_46433(cx - 100, y).method_46437(200, 20).method_46431());
        y += gap;

        // BR feedback — greyed out when BR mode is off
        class_4185 brFeedbackBtn = class_4185.method_46430(brFeedbackText(), btn -> {
            LootJournalConfig.brFeedbackInChat = !LootJournalConfig.brFeedbackInChat;
            btn.method_25355(brFeedbackText());
        }).method_46433(cx - 100, y).method_46437(200, 20).method_46431();
        brFeedbackBtn.field_22763 = LootJournalConfig.blockRandomizerMode;
        this.method_37063(brFeedbackBtn);
        y += gap;

        // ── General output options ────────────────────────────────────────────
        addToggle(cx, y, "Summary on Disconnect",
                LootJournalConfig.showSummaryOnDisconnect,
                v -> LootJournalConfig.showSummaryOnDisconnect = v);
        y += gap;

        addToggle(cx, y, "Write Session JSON",
                LootJournalConfig.writeSessionJson,
                v -> LootJournalConfig.writeSessionJson = v);
        y += gap;

        addToggle(cx, y, "Write Statistics JSON",
                LootJournalConfig.writeStatisticsJson,
                v -> LootJournalConfig.writeStatisticsJson = v);
        y += gap;

        addToggle(cx, y, "Write Per-Break Events",
                LootJournalConfig.writeBreakEvents,
                v -> LootJournalConfig.writeBreakEvents = v);
        y += gap;

        // ── Attribution window ±20 ticks ──────────────────────────────────────
        windowLabelY = y + 5;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("  -  "), btn ->
                LootJournalConfig.attributionWindowTicks =
                        Math.max(20, LootJournalConfig.attributionWindowTicks - 20))
                .method_46433(cx - 100, y).method_46437(40, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("  +  "), btn ->
                LootJournalConfig.attributionWindowTicks =
                        Math.min(200, LootJournalConfig.attributionWindowTicks + 20))
                .method_46433(cx + 60, y).method_46437(40, 20).method_46431());

        // ── Done ─────────────────────────────────────────────────────────────
        this.method_37063(class_4185.method_46430(class_5244.field_24334, btn -> method_25419())
                .method_46433(cx - 100, this.field_22790 - 27).method_46437(200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        // Title
        context.method_27534(this.field_22793, this.field_22785,
                this.field_22789 / 2, 15, 0xFFFFFF);
        // Attribution window label — redrawn every frame so it reflects live value
        context.method_27534(this.field_22793,
                class_2561.method_43470("Attribution Window: " + LootJournalConfig.attributionWindowTicks + " ticks"),
                this.field_22789 / 2, windowLabelY, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        LootJournalConfig.save();
        assert this.field_22787 != null;
        this.field_22787.method_1507(this.parent);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void addToggle(int cx, int y, String label, boolean initial, Consumer<Boolean> setter) {
        boolean[] state = {initial};
        this.method_37063(class_4185.method_46430(
                toggleText(label, state[0]),
                btn -> {
                    state[0] = !state[0];
                    setter.accept(state[0]);
                    btn.method_25355(toggleText(label, state[0]));
                }
        ).method_46433(cx - 100, y).method_46437(200, 20).method_46431());
    }

    private static class_2561 toggleText(String label, boolean on) {
        return class_2561.method_43470(label + ": " + (on ? "§aON" : "§cOFF"));
    }

    private static class_2561 brModeText() {
        return class_2561.method_43470("Block Randomizer Mode: " +
                (LootJournalConfig.blockRandomizerMode ? "§aON" : "§cOFF"));
    }

    private static class_2561 brFeedbackText() {
        return class_2561.method_43470("Drop Feedback in Chat: " +
                (LootJournalConfig.brFeedbackInChat ? "§aON" : "§cOFF"));
    }
}
